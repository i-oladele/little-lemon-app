import Onboarding from '@/screens/Onboarding';

export default Onboarding;
